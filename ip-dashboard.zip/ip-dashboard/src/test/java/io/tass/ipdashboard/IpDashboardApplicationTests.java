package io.tass.ipdashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
