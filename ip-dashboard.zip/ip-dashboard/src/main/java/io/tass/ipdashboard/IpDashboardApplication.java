package io.tass.ipdashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IpDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(IpDashboardApplication.class, args);
	}

}
